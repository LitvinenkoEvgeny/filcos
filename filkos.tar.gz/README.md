# FILCOS
## Install and run:
- git clone https://github.com/LitvinenkoEvgeny/filcos/tree/master 
- cd filcos 
- npm install 
- npm run dev